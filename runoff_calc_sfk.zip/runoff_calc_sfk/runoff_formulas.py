import math


class RunoffCalculator:
    """
    Расчет гидрологических параметров и модуля стока по методике В.М. Калинина
    ФИНАЛЬНАЯ ИСПРАВЛЕННАЯ ВЕРСИЯ
    """

    @staticmethod
    def calculate_bcr(Kf):
        """Базовый коэффициент регулирования стока (1.1)"""
        if Kf <= 0:
            return 1.0
        return 1 + (0.25 / math.sqrt(Kf))

    @staticmethod
    def calculate_p(bcr):
        """Параметр перераспределения влаги (1.2)"""
        if bcr - 1 == 0:
            return 1.0
        return 1.0 / math.pow(1 + math.pow(2.0 / (bcr - 1), 7), 1.0 / 3)

    @staticmethod
    def calculate_c(Kf):
        """Коэффициент инфильтрации (1.3)"""
        return 1 + 0.85 * Kf

    @staticmethod
    def calculate_V(bcr):
        """Показатель вариации стока (1.4)"""
        return 13.3 * math.pow(bcr - 1, 1.77)

    @staticmethod
    def calculate_bt_drained(bcr):
        """Коэффициент базового стока для дренированных (1.5)"""
        return 1 + 0.29 * math.pow(bcr - 1, 1.58)

    @staticmethod
    def calculate_f_drained(bcr):
        """Фактор фильтрации для дренированных (1.6)"""
        if bcr - 1 == 0:
            return 0.8
        return 0.8 - 0.64 / math.pow(1 + math.pow(0.85 / (bcr - 1), 1.6), 0.625)

    @staticmethod
    def calculate_bt_boggy(bcr):
        """Коэффициент базового стока для заболоченных (1.7)"""
        return 1 + 0.1 * math.pow(bcr - 1, 3.75)

    @staticmethod
    def calculate_f_boggy(bcr):
        """Фактор фильтрации для заболоченных (1.8)"""
        if bcr - 1 == 0:
            return 1.0
        return 1 - 0.46 / math.pow(1 + math.pow(0.85 / (bcr - 1), 1.6), 0.625)

    @staticmethod
    def calculate_b(bt, bcr, p, f, c, Hcold, V):
        """Комплексный коэффициент стока (1.9)"""
        try:
            if p <= 0 or p >= 1 or Hcold <= 0:
                return bt

            term1 = math.pow(1.0 / (1 - p), 3)
            term2 = math.pow(f / (c * Hcold), 3 * V)
            denominator1 = math.pow(term1 + term2, 1.0 / 3)

            term3 = math.pow(1.0 / p, 3)
            term4 = math.pow((f * p) / Hcold, 3)
            denominator2 = math.pow(term3 + term4, 1.0 / 3)

            if denominator1 == 0 or denominator2 == 0:
                return bt

            return bt + (bcr - bt) / denominator1 + (bcr + bt) / denominator2

        except Exception:
            return bt

    @staticmethod
    def calculate_m(b):
        """Показатель нелинейности (1.10)"""
        if b - 1 == 0:
            return 1.56
        return 1.56 / math.pow(b - 1, 0.92)

    @staticmethod
    def calculate_a(i, A):
        """Коэффициент аккумуляции (1.11)"""
        try:
            CH = 0.8 * math.exp(-0.027 * i)
            ZH = math.pow(1 + math.pow(30 / A, 3), 1.0 / 3)

            if ZH == 0:
                return 1.0

            return 1 - CH / ZH
        except Exception:
            return 0.5

    @staticmethod
    def calculate_nc_drained(a, b, GWlevel, Hcrit, m):
        """Нормализованный коэффициент для дренированных (1.12)"""
        try:
            if Hcrit == 0:
                return a

            ratio = b * (GWlevel / Hcrit)
            denominator = math.pow(1 + math.pow(ratio, -3 * m), 1.0 / 3)

            if denominator == 0:
                return a

            return a / denominator
        except Exception:
            return a

    @staticmethod
    def calculate_nb_boggy(a, nc, GWlevel, Hcrit):
        """Нормализованный коэффициент для заболоченных (1.13)"""
        try:
            if Hcrit == 0:
                return a

            ratio = 3.7 * (GWlevel / Hcrit)
            denominator = math.pow(1 + math.pow(ratio, -5), 1.0 / 3)

            if denominator == 0:
                return a

            return a - (a - nc) / denominator
        except Exception:
            return a

    @staticmethod
    def calculate_Rsp_drained(Sn, a, b, pW_norm, m):
        """
        Весенний сток для дренированных (1.14)
        ИСПРАВЛЕНО: правильная зависимость от влажности
        """
        try:
            if pW_norm < 0:
                pW_norm = 0
            if pW_norm > 1:
                pW_norm = 1

            # При полном насыщении — максимальный сток
            if pW_norm >= 0.99:
                return Sn * a
            
            # При нулевой влажности — минимальный сток
            if pW_norm <= 0.01:
                return Sn * a * 0.1

            # Исправленная формула: используем (1 - pW_norm) для обратной зависимости
            x = b * (1 - pW_norm)
            denominator = math.pow(1 + math.pow(x, 3 * m), 1.0 / 3)

            if denominator == 0:
                return Sn * a

            Rsp = Sn * a / denominator
            
            # Ограничения
            if Rsp > Sn:
                Rsp = Sn * 0.95

            return max(Rsp, 0.01)

        except Exception:
            return Sn * a * 0.3

    @staticmethod
    def calculate_Rsp_boggy(Sn, a, nb, GWlevel, Hcrit):
        """Весенний сток для заболоченных (1.15)"""
        try:
            if Hcrit == 0:
                return Sn * 0.3

            ratio = 3.7 * (GWlevel / Hcrit)
            denominator = math.pow(1 + math.pow(ratio, -5), 1.0 / 3)

            if denominator == 0:
                return Sn * 0.3

            Rsp = Sn * (a - (a - nb) / denominator)
            
            # Для болот сток не более 50% снегозапасов
            if Rsp > Sn:
                Rsp = Sn
            
            return max(Rsp, 0.01)

        except Exception:
            return Sn * 0.2

    @staticmethod
    def calculate_Ryr(Rsp, b):
        """Годовой сток (1.16)"""
        return b * Rsp

    @staticmethod
    def normalize_pW(pW_raw, PV, MG):
        """Нормализация влагозапасов к безразмерному виду (0..1)"""
        try:
            if 0 <= pW_raw <= 1:
                return pW_raw

            if PV - MG > 0:
                pW_norm = (pW_raw - MG) / (PV - MG)
                if pW_norm < 0:
                    pW_norm = 0
                if pW_norm > 1:
                    pW_norm = 1
                return pW_norm
            return 0.5
        except:
            return 0.5

    @staticmethod
    def calculate_all_parameters(Kf, i, A, pW, Sn, Hcold, GWlevel, Hcrit,
                                 PV, MG, landscape_type, y=0):
        """Полный расчет всех параметров"""
        try:
            bcr = RunoffCalculator.calculate_bcr(Kf)
            p = RunoffCalculator.calculate_p(bcr)
            c = RunoffCalculator.calculate_c(Kf)
            V = RunoffCalculator.calculate_V(bcr)

            if landscape_type == 0:
                bt = RunoffCalculator.calculate_bt_drained(bcr)
                f = RunoffCalculator.calculate_f_drained(bcr)
            else:
                bt = RunoffCalculator.calculate_bt_boggy(bcr)
                f = RunoffCalculator.calculate_f_boggy(bcr)

            b = RunoffCalculator.calculate_b(bt, bcr, p, f, c, Hcold, V)
            if b < 1.0:
                b = 1.0
            if b > 3.0:
                b = 3.0

            m = RunoffCalculator.calculate_m(b)
            if m < 0.5:
                m = 0.5
            if m > 5.0:
                m = 5.0

            a = RunoffCalculator.calculate_a(i, A)
            if a < 0.1:
                a = 0.1
            if a > 0.99:
                a = 0.99

            nc = RunoffCalculator.calculate_nc_drained(a, b, GWlevel, Hcrit, m)
            pW_norm = RunoffCalculator.normalize_pW(pW, PV, MG)

            if landscape_type == 0:
                Rsp = RunoffCalculator.calculate_Rsp_drained(Sn, a, b, pW_norm, m)
            else:
                nb = RunoffCalculator.calculate_nb_boggy(a, nc, GWlevel, Hcrit)
                Rsp = RunoffCalculator.calculate_Rsp_boggy(Sn, a, nb, GWlevel, Hcrit)

            Ryr = RunoffCalculator.calculate_Ryr(Rsp, b)

            return {
                'bcr': bcr, 'p': p, 'c': c, 'V': V, 'bt': bt, 'f': f,
                'b': b, 'm': m, 'a': a, 'nc': nc, 'pW_norm': pW_norm,
                'Rsp': max(0, Rsp), 'Ryr': max(0, Ryr), 'success': True
            }

        except Exception as e:
            return {
                'success': False, 'error': str(e),
                'Rsp': 0, 'Ryr': 0, 'bcr': 1.0, 'b': 1.0, 'a': 0.5, 'm': 1.56
            }