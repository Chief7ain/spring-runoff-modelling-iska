def classFactory(iface):
    from .runoff_plugin import RunoffPlugin
    return RunoffPlugin(iface)
