from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
import os
from .runoff_dialog import RunoffDialog


class RunoffPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None

    def initGui(self):
        """Создание кнопки в интерфейсе"""
        icon_path = os.path.join(os.path.dirname(__file__), 'icon.png')

        if os.path.exists(icon_path):
            icon = QIcon(icon_path)
            self.action = QAction(icon, "Расчет стока СФК (Калинин)", self.iface.mainWindow())
        else:
            self.action = QAction("Расчет стока СФК (Калинин)", self.iface.mainWindow())

        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("Гидрология", self.action)

    def unload(self):
        """Удаление плагина"""
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("Гидрология", self.action)

    def run(self):
        """Запуск диалога"""
        if not self.dialog:
            self.dialog = RunoffDialog(self.iface)
        self.dialog.show()
        self.dialog.raise_()
