from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QComboBox, QPushButton, QTableWidget, QTableWidgetItem,
    QMessageBox, QGroupBox, QFormLayout,
    QDoubleSpinBox, QHeaderView, QTabWidget, QTextEdit,
    QWidget, QProgressBar, QSizePolicy
)
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsVectorLayer, QgsField, QgsProject, QgsApplication, QgsFeature
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QFont, QColor
from .runoff_formulas import RunoffCalculator


class RunoffDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.layer = None
        self._is_creating = False
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Расчет гидрологических параметров и стока (методика В.М. Калинина)")
        
        # Настройка размера окна
        self.setMinimumWidth(800)
        self.setMinimumHeight(600)
        self.setMaximumWidth(3000)
        self.setMaximumHeight(2000)
        self.resize(1000, 750)
        
        # Разрешаем разворачивание окна на весь экран
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint)

        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)

        # Создаем вкладки
        tabs = QTabWidget()
        tabs.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # Вкладка 1: Выбор слоя и параметров
        tab1 = self.create_input_tab()
        tabs.addTab(tab1, "1. Входные данные")

        # Вкладка 2: Результаты
        self.tab2 = self.create_results_tab()
        tabs.addTab(self.tab2, "2. Результаты")

        main_layout.addWidget(tabs)

        # Прогресс бар
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)

        # Кнопки внизу
        buttons_layout = QHBoxLayout()
        buttons_layout.setContentsMargins(0, 10, 0, 0)

        self.calc_button = QPushButton("Выполнить расчет")
        self.calc_button.clicked.connect(self.calculate_runoff)
        self.calc_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                font-weight: bold;
                padding: 10px;
                font-size: 14px;
            }
        """)
        buttons_layout.addWidget(self.calc_button)

        self.close_button = QPushButton("Закрыть")
        self.close_button.clicked.connect(self.reject)
        buttons_layout.addWidget(self.close_button)

        main_layout.addLayout(buttons_layout)

        self.setLayout(main_layout)

        # Загружаем слои
        self.populate_layers()

    def create_input_tab(self):
        """Создание вкладки ввода данных"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)

        # Группа выбора слоя
        layer_group = QGroupBox("Выбор полигонального слоя")
        layer_layout = QHBoxLayout()

        layer_layout.addWidget(QLabel("Слой:"))
        self.layer_combo = QComboBox()
        self.layer_combo.setMinimumWidth(300)
        self.layer_combo.currentIndexChanged.connect(self.on_layer_changed)
        layer_layout.addWidget(self.layer_combo)

        self.refresh_btn = QPushButton("Обновить")
        self.refresh_btn.clicked.connect(self.populate_layers)
        layer_layout.addWidget(self.refresh_btn)

        layer_group.setLayout(layer_layout)
        layout.addWidget(layer_group)

        # Группа сопоставления полей
        mapping_group = QGroupBox("Сопоставление полей слоя")
        mapping_layout = QVBoxLayout()

        self.info_label = QLabel("Выберите поля, соответствующие гидрологическим параметрам:")
        mapping_layout.addWidget(self.info_label)

        self.mapping_table = QTableWidget()
        self.mapping_table.setColumnCount(3)
        self.mapping_table.setHorizontalHeaderLabels(["Параметр", "Описание", "Поле слоя"])
        
        # Настройка растяжения столбцов таблицы сопоставления
        header = self.mapping_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        
        # Разрешаем таблице растягиваться
        self.mapping_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        mapping_layout.addWidget(self.mapping_table)

        mapping_group.setLayout(mapping_layout)
        layout.addWidget(mapping_group)

        # Кнопки для работы с полями
        buttons_layout = QHBoxLayout()

        self.auto_map_btn = QPushButton("Авто-сопоставление")
        self.auto_map_btn.clicked.connect(self.auto_mapping)
        self.auto_map_btn.setEnabled(False)
        buttons_layout.addWidget(self.auto_map_btn)

        self.clear_map_btn = QPushButton("Очистить сопоставление")
        self.clear_map_btn.clicked.connect(self.clear_mapping)
        self.clear_map_btn.setEnabled(False)
        buttons_layout.addWidget(self.clear_map_btn)

        layout.addLayout(buttons_layout)

        widget.setLayout(layout)
        return widget

    def create_results_tab(self):
        """Создание вкладки результатов"""
        widget = QWidget()
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 5, 5, 5)

        # Информация об общих результатах
        self.summary_group = QGroupBox("Общие результаты")
        summary_layout = QVBoxLayout()

        # Общая площадь
        self.total_area_label = QLabel("Общая площадь водосбора: -- км²")
        self.total_area_label.setFont(QFont("Arial", 10, QFont.Bold))
        summary_layout.addWidget(self.total_area_label)

        # Разделитель
        line1 = QLabel("─" * 50)
        line1.setStyleSheet("color: #888;")
        summary_layout.addWidget(line1)

        # Весенний сток
        spring_title = QLabel("ВЕСЕННИЙ СТОК")
        spring_title.setFont(QFont("Arial", 10, QFont.Bold))
        spring_title.setStyleSheet("color: #2E7D32;")
        summary_layout.addWidget(spring_title)

        self.total_spring_volume_label = QLabel("Общий объем весеннего стока: -- мм·км²")
        self.total_spring_volume_label.setFont(QFont("Arial", 10))
        summary_layout.addWidget(self.total_spring_volume_label)

        self.total_spring_runoff_label = QLabel("Общая величина весеннего стока: -- мм")
        self.total_spring_runoff_label.setFont(QFont("Arial", 10))
        summary_layout.addWidget(self.total_spring_runoff_label)

        # Разделитель
        line2 = QLabel("─" * 50)
        line2.setStyleSheet("color: #888;")
        summary_layout.addWidget(line2)

        # Годовой сток
        year_title = QLabel("ГОДОВОЙ СТОК")
        year_title.setFont(QFont("Arial", 10, QFont.Bold))
        year_title.setStyleSheet("color: #1565C0;")
        summary_layout.addWidget(year_title)

        self.total_year_volume_label = QLabel("Общий объем годового стока: -- мм·км²")
        self.total_year_volume_label.setFont(QFont("Arial", 10))
        summary_layout.addWidget(self.total_year_volume_label)

        self.total_year_runoff_label = QLabel("Общая величина годового стока: -- мм")
        self.total_year_runoff_label.setFont(QFont("Arial", 10))
        summary_layout.addWidget(self.total_year_runoff_label)

        self.summary_group.setLayout(summary_layout)
        layout.addWidget(self.summary_group)

        # Таблица детальных результатов (7 столбцов)
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(7)
        self.results_table.setHorizontalHeaderLabels([
            "ID", "FID", "Landscape", "Площадь (км²)", "Доля (%)", "Весенний сток (мм)", "Годовой сток (мм)"
        ])
        self.results_table.setAlternatingRowColors(True)
        
        # Настройка растяжения столбцов таблицы результатов
        header = self.results_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)  # ID - по содержимому
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # FID - по содержимому
        header.setSectionResizeMode(2, QHeaderView.Stretch)           # Landscape - растягивается
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)  # Площадь - по содержимому
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)  # Доля - по содержимому
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)  # Весенний сток - по содержимому
        header.setSectionResizeMode(6, QHeaderView.ResizeToContents)  # Годовой сток - по содержимому
        
        # Разрешаем таблице растягиваться
        self.results_table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        layout.addWidget(self.results_table)

        # Текстовое поле для логов
        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(150)
        self.log_text.setReadOnly(True)
        layout.addWidget(self.log_text)

        widget.setLayout(layout)
        return widget

    def populate_layers(self):
        """Заполнение списка слоев"""
        self.layer_combo.clear()
        self.layer_combo.addItem("-- Выберите слой --", None)

        layers = QgsProject.instance().mapLayers().values()
        polygon_layers = []

        for layer in layers:
            if isinstance(layer, QgsVectorLayer) and layer.geometryType() == 2:
                polygon_layers.append(layer)

        for layer in polygon_layers:
            source_type = layer.dataProvider().name()
            self.layer_combo.addItem(f"{layer.name()} [{source_type}]", layer)

        if polygon_layers:
            self.log_text.append(f"Найдено полигональных слоев: {len(polygon_layers)}")

    def on_layer_changed(self):
        """Обработчик смены слоя"""
        self.layer = self.layer_combo.currentData()
        self.update_mapping_table()
        
        # Проверяем сумму площадей при выборе слоя
        if self.layer:
            self.check_layer_area()

        enabled = self.layer is not None
        self.auto_map_btn.setEnabled(enabled)
        self.clear_map_btn.setEnabled(enabled)

    def check_layer_area(self):
        """Проверка суммы площадей в слое из атрибута"""
        if not self.layer:
            return
        
        # Получаем поле для площади из сопоставления
        area_field = None
        for i in range(self.mapping_table.rowCount()):
            param = self.mapping_table.item(i, 0).text()
            if param == 'F':
                combo = self.mapping_table.cellWidget(i, 2)
                area_field = combo.currentData()
                break
        
        if area_field:
            total = 0
            count = 0
            for feature in self.layer.getFeatures():
                try:
                    val = feature[area_field]
                    if val is not None:
                        total += float(val)
                        count += 1
                except:
                    pass
            self.log_text.append(f"Сумма площадей по полю '{area_field}': {total:.2f} км² (объектов: {count})")
        else:
            self.log_text.append("Поле с площадью не выбрано! Убедитесь, что поле 'F' сопоставлено.")

    def update_mapping_table(self):
        """Обновление таблицы сопоставления"""
        if not self.layer:
            self.mapping_table.setRowCount(0)
            return

        # Параметры для сопоставления по методике В.М. Калинина
        parameters = [
            ('F', 'Площадь (км²)', True),
            ('i', 'Уклон (‰)', True),
            ('Kf', 'Коэффициент фильтрации (м/сут)', True),
            ('pW', 'Влагозапасы', True),
            ('Sn', 'Снегозапасы (мм)', True),
            ('Hcold', 'Глубина промерзания (м)', True),
            ('GWlevel', 'Уровень грунтовых вод (м)', False),
            ('Hcrit', 'Критическая глубина (м)', False),
            ('PV', 'Полная влагоемкость', True),
            ('MG', 'Максимальная гигроскопичность', True),
            ('landscape_type', 'Тип ландшафта (0-дренированный, 1-заболоченный)', True)
        ]

        field_names = [field.name() for field in self.layer.fields()]

        self.mapping_table.setRowCount(len(parameters))

        for i, (param, desc, required) in enumerate(parameters):
            # Параметр
            param_item = QTableWidgetItem(param)
            if required:
                param_item.setBackground(QColor(255, 255, 200))
                param_item.setToolTip("Обязательный параметр")
            self.mapping_table.setItem(i, 0, param_item)

            # Описание
            desc_item = QTableWidgetItem(desc)
            desc_item.setFlags(desc_item.flags() & ~Qt.ItemIsEditable)
            self.mapping_table.setItem(i, 1, desc_item)

            # ComboBox с полями
            combo = QComboBox()
            combo.addItem("-- не выбрано --", None)
            for field_name in sorted(field_names):
                combo.addItem(field_name, field_name)
            self.mapping_table.setCellWidget(i, 2, combo)

    def auto_mapping(self):
        """Автоматическое сопоставление полей"""
        if not self.layer:
            return

        field_names = [field.name() for field in self.layer.fields()]

        # Словарь соответствий для методики Калинина
        mappings = {
            'F': ['area', 'площадь', 'f', 'square', 'km2', 'size', 'Area', 'Area_km2', 'AREA'],
            'i': ['уклон', 'slope', 'i', 'gradient', 'наклон', 'Slope_mean'],
            'Kf': ['kf', 'фильтр', 'filt', 'filter', 'коэффиц', 'permeability', 'Kf'],
            'pW': ['pw', 'влагозапасы', 'moist', 'water', 'влажность', 'pW'],
            'Sn': ['sn', 'снегозапасы', 'snow', 'stock', 'снег', 'Snow'],
            'Hcold': ['hcold', 'промерз', 'freeze', 'depth', 'глубина', 'Hcold'],
            'GWlevel': ['gwlevel', 'уровень', 'level', 'groundwater', 'гв', 'GW_Level'],
            'Hcrit': ['hcrit', 'крит', 'critical', 'предел', 'limit', 'Hcritical'],
            'PV': ['pv', 'влагоемк', 'capacity', 'полная', 'вместимость', 'PV'],
            'MG': ['mg', 'гигроск', 'гигроскопичность', 'MG'],
            'landscape_type': ['type', 'тип', 'land', 'ландшафт', 'class', 'Land_type']
        }

        # Исключаем поля ID
        excluded_patterns = ['id', 'ID', 'Id', 'OBJECTID', 'objectid', 'FID', 'fid']

        for i in range(self.mapping_table.rowCount()):
            param = self.mapping_table.item(i, 0).text()
            combo = self.mapping_table.cellWidget(i, 2)

            best_match = None
            best_score = 0

            search_words = mappings.get(param, [param.lower()])

            for field_name in field_names:
                if any(excluded in field_name for excluded in excluded_patterns):
                    continue

                field_lower = field_name.lower()
                score = 0

                if param.lower() == field_lower:
                    score = 100
                else:
                    for word in search_words:
                        if word.lower() == field_lower:
                            score = 95
                            break
                        elif word.lower() in field_lower:
                            score = 70
                            break
                    if param.lower()[:2] in field_lower:
                        score = max(score, 40)

                if score > best_score:
                    best_score = score
                    best_match = field_name

            if best_match and best_score >= 70:
                for idx in range(combo.count()):
                    if combo.itemData(idx) == best_match:
                        combo.setCurrentIndex(idx)
                        self.log_text.append(f"Сопоставлено: {param} -> {best_match}")
                        break

        self.log_text.append("Авто-сопоставление полей выполнено")

    def clear_mapping(self):
        """Очистка сопоставления полей"""
        for i in range(self.mapping_table.rowCount()):
            combo = self.mapping_table.cellWidget(i, 2)
            if combo:
                combo.setCurrentIndex(0)
        self.log_text.append("Сопоставление полей очищено")

    def get_field_mapping(self):
        """Получение сопоставления полей"""
        mapping = {}
        missing = []

        for i in range(self.mapping_table.rowCount()):
            param = self.mapping_table.item(i, 0).text()
            combo = self.mapping_table.cellWidget(i, 2)
            field_name = combo.currentData()

            if field_name:
                mapping[param] = field_name
            else:
                missing.append(param)

        return mapping, missing

    def calculate_runoff(self):
        """Выполнение расчета по методике В.М. Калинина"""
        if not self.layer:
            QMessageBox.critical(self, "Ошибка", "Выберите слой для расчета")
            return

        mapping, missing = self.get_field_mapping()

        required_params = ['F', 'i', 'Kf', 'pW', 'Sn', 'Hcold', 'PV', 'MG', 'landscape_type']
        missing_required = [p for p in required_params if p not in mapping]

        if missing_required:
            QMessageBox.critical(
                self, "Ошибка",
                f"Не указаны обязательные поля:\n{', '.join(missing_required)}"
            )
            return

        # Отладочная информация о слое
        self.log_text.clear()
        self.log_text.append("=== ИНФОРМАЦИЯ О СЛОЕ ===")
        self.log_text.append(f"Имя слоя: {self.layer.name()}")
        self.log_text.append(f"Тип источника: {self.layer.dataProvider().name()}")
        total_features = self.layer.featureCount()
        self.log_text.append(f"Количество объектов в слое: {total_features}")
        self.log_text.append("")
        
        # Проверяем, какое поле используется для площади
        area_field_name = mapping.get('F', 'Не указано')
        self.log_text.append(f"Поле для площади (F): {area_field_name}")
        
        # ЯВНОЕ СУММИРОВАНИЕ ПЛОЩАДЕЙ ИЗ АТРИБУТА
        total_area_from_attr = 0
        area_values = []
        valid_count = 0
        null_count = 0
        error_count = 0
        
        for feature in self.layer.getFeatures():
            try:
                val = feature[area_field_name]
                if val is None:
                    null_count += 1
                    continue
                area_val = float(val)
                if area_val > 0:
                    total_area_from_attr += area_val
                    area_values.append(area_val)
                    valid_count += 1
                else:
                    error_count += 1
            except Exception as e:
                error_count += 1
        
        self.log_text.append(f"Сумма площадей из атрибута '{area_field_name}': {total_area_from_attr:.2f} км²")
        self.log_text.append(f"Корректных значений площади: {valid_count}")
        self.log_text.append(f"NULL значений: {null_count}")
        self.log_text.append(f"Ошибочных значений: {error_count}")
        if area_values:
            self.log_text.append(f"Минимальная площадь: {min(area_values):.2f} км²")
            self.log_text.append(f"Максимальная площадь: {max(area_values):.2f} км²")
        self.log_text.append("")

        # Собираем данные
        features_data = []
        self.log_text.append("Начинаем сбор данных...")

        self.progress_bar.setMaximum(total_features)
        self.progress_bar.setVisible(True)

        process_errors = 0
        processed_count = 0

        for i, feature in enumerate(self.layer.getFeatures()):
            try:
                # Получаем ID объекта (оригинальный fid)
                original_fid = feature.id()
                
                # Получаем тип ландшафта
                if 'landscape_type' in mapping:
                    landscape_type = feature[mapping['landscape_type']]
                    if landscape_type is None:
                        landscape_type = 0
                else:
                    landscape_type = 0

                if landscape_type not in [0, 1]:
                    landscape_type = 0

                # Получаем название ландшафта
                landscape_name = ""
                for field_name in ['Landscape', 'LANDSCAPE', 'landscape', 'Name', 'NAME', 'name', 'Название', 'НАЗВАНИЕ']:
                    if field_name in mapping:
                        val = feature[mapping[field_name]]
                        landscape_name = str(val) if val is not None else ""
                        break
                if not landscape_name:
                    for field in self.layer.fields():
                        if field.name().lower() in ['landscape', 'land', 'name', 'название']:
                            val = feature[field.name()]
                            landscape_name = str(val) if val is not None else ""
                            break

                # Чтение площади из атрибута
                area_val_raw = feature[mapping['F']]
                if area_val_raw is None:
                    process_errors += 1
                    continue
                    
                area_value = float(area_val_raw)
                if area_value <= 0:
                    process_errors += 1
                    continue
                
                # Для отладки - выводим первые 5 значений
                if i < 5:
                    self.log_text.append(f"Объект {i+1}: FID={original_fid}, площадь = {area_value:.2f} км², ландшафт = {landscape_name}")

                # Чтение остальных параметров
                i_val = float(feature[mapping['i']]) if feature[mapping['i']] is not None else 0
                kf_val = float(feature[mapping['Kf']]) if feature[mapping['Kf']] is not None else 0
                pw_val = float(feature[mapping['pW']]) if feature[mapping['pW']] is not None else 0
                sn_val = float(feature[mapping['Sn']]) if feature[mapping['Sn']] is not None else 0
                hcold_val = float(feature[mapping['Hcold']]) if feature[mapping['Hcold']] is not None else 0
                pv_val = float(feature[mapping['PV']]) if feature[mapping['PV']] is not None else 0
                mg_val = float(feature[mapping['MG']]) if feature[mapping['MG']] is not None else 0

                # Для заболоченных - значения по умолчанию, если поля не найдены
                if landscape_type == 1:
                    if 'GWlevel' in mapping and 'Hcrit' in mapping:
                        GWlevel = float(feature[mapping['GWlevel']]) if feature[mapping['GWlevel']] is not None else 0.5
                        Hcrit = float(feature[mapping['Hcrit']]) if feature[mapping['Hcrit']] is not None else 1.0
                    else:
                        GWlevel = 0.5
                        Hcrit = 1.0
                else:
                    GWlevel = 2.0
                    Hcrit = 2.0

                data = {
                    'F': area_value,
                    'i': i_val,
                    'Kf': kf_val,
                    'pW': pw_val,
                    'Sn': sn_val,
                    'Hcold': hcold_val,
                    'PV': pv_val,
                    'MG': mg_val,
                    'GWlevel': GWlevel,
                    'Hcrit': Hcrit,
                    'landscape_type': landscape_type,
                    'landscape_name': landscape_name,
                    'original_fid': original_fid,
                    'feature_id': feature.id(),
                    'geometry': feature.geometry(),
                    'original_attributes': feature.attributes()
                }

                features_data.append(data)
                processed_count += 1

            except Exception as e:
                process_errors += 1
                if process_errors <= 5:
                    self.log_text.append(f"Ошибка при чтении объекта {i+1}: {str(e)}")

            self.progress_bar.setValue(i + 1)
            QgsApplication.processEvents()

        self.log_text.append("")
        self.log_text.append(f"Успешно обработано объектов для расчета: {processed_count}")
        self.log_text.append(f"Пропущено/с ошибками: {process_errors}")
        self.log_text.append("")

        if processed_count == 0:
            self.progress_bar.setVisible(False)
            QMessageBox.critical(self, "Ошибка", "Нет данных для расчета")
            return

        # Выполняем расчет по методике Калинина
        self.log_text.append("Расчет гидрологических параметров...")

        results = []
        total_area = 0
        total_spring_volume = 0
        total_year_volume = 0

        for i, data in enumerate(features_data):
            # Полный расчет всех параметров
            params = RunoffCalculator.calculate_all_parameters(
                Kf=data['Kf'],
                i=data['i'],
                A=data['F'],
                pW=data['pW'],
                Sn=data['Sn'],
                Hcold=data['Hcold'],
                GWlevel=data['GWlevel'],
                Hcrit=data['Hcrit'],
                PV=data['PV'],
                MG=data['MG'],
                landscape_type=data['landscape_type'],
                y=0
            )

            Rsp = params['Rsp']  # Весенний сток, мм
            Ryr = params['Ryr']  # Годовой сток, мм

            total_area += data['F']
            total_spring_volume += Rsp * data['F']
            total_year_volume += Ryr * data['F']

            results.append({
                'geometry': data['geometry'],
                'original_attributes': data['original_attributes'],
                'landscape_name': data['landscape_name'],
                'original_fid': data['original_fid'],
                'attributes': {
                    'F': data['F'],
                    'i': data['i'],
                    'Kf': data['Kf'],
                    'landscape_type': data['landscape_type'],
                    'Rsp': Rsp,
                    'Ryr': Ryr,
                    'bcr': params['bcr'],
                    'b': params['b'],
                    'm': params['m'],
                    'a': params['a']
                }
            })

        # Общая величина стока (средневзвешенная)
        avg_spring_runoff = total_spring_volume / total_area if total_area > 0 else 0
        avg_year_runoff = total_year_volume / total_area if total_area > 0 else 0

        self.log_text.append("")
        self.log_text.append("=== ИТОГОВЫЕ РЕЗУЛЬТАТЫ ===")
        self.log_text.append(f"Сумма площадей ИЗ АТРИБУТА '{area_field_name}': {total_area:.2f} км²")
        self.log_text.append(f"Общий объем весеннего стока: {total_spring_volume:.2f} мм·км²")
        self.log_text.append(f"Общая величина весеннего стока: {avg_spring_runoff:.2f} мм")
        self.log_text.append(f"Общий объем годового стока: {total_year_volume:.2f} мм·км²")
        self.log_text.append(f"Общая величина годового стока: {avg_year_runoff:.2f} мм")

        # Отображаем результаты в таблице
        self.display_results(results, total_area,
                             total_spring_volume, avg_spring_runoff,
                             total_year_volume, avg_year_runoff)

        # Создаем слой с результатами
        self._create_layer_once(results, self.layer, total_area,
                                 total_spring_volume, avg_spring_runoff,
                                 total_year_volume, avg_year_runoff)

        self.progress_bar.setVisible(False)

        QMessageBox.information(
            self, "Расчет завершен",
            f"Расчет гидрологических параметров по методике В.М. Калинина выполнен!\n\n"
            f"Всего контуров: {len(results)}\n"
            f"Общая площадь водосбора: {total_area:.2f} км²\n\n"
            f"Весенний сток:\n"
            f"  • Общий объем: {total_spring_volume:.2f} мм·км²\n"
            f"  • Общая величина: {avg_spring_runoff:.2f} мм\n\n"
            f"Годовой сток:\n"
            f"  • Общий объем: {total_year_volume:.2f} мм·км²\n"
            f"  • Общая величина: {avg_year_runoff:.2f} мм\n\n"
            f"Создан новый слой с результатами: {self.layer.name()}_runoff_results"
        )

    def _create_layer_once(self, results, source_layer, total_area,
                            total_spring_volume, avg_spring_runoff,
                            total_year_volume, avg_year_runoff):
        """Создание слоя только один раз за расчет"""

        if self._is_creating:
            self.log_text.append("Создание слоя уже выполняется, пропускаем")
            return

        self._is_creating = True

        try:
            from qgis.core import QgsVectorLayer, QgsField, QgsFeature, QgsProject

            layer_name = f"{source_layer.name()}_runoff_results"

            # Удаляем старый слой если есть
            existing_layers = QgsProject.instance().mapLayersByName(layer_name)
            for old_layer in existing_layers:
                QgsProject.instance().removeMapLayer(old_layer.id())
                self.log_text.append(f"Удален старый слой: {layer_name}")

            # Создаем новый слой
            temp_layer = QgsVectorLayer(f"Polygon?crs={source_layer.crs().authid()}",
                                        layer_name, "memory")

            provider = temp_layer.dataProvider()

            # Поля результатов (добавлено поле FID)
            fields = [
                QgsField('FID', QVariant.Int, 'integer', 10, 0),
                QgsField('Landscape', QVariant.String, 'text', 100),
                QgsField('F_km2', QVariant.Double, 'double', 10, 2),
                QgsField('Slope', QVariant.Double, 'double', 10, 2),
                QgsField('Kf', QVariant.Double, 'double', 10, 4),
                QgsField('L_type', QVariant.Int),
                QgsField('Rsp_mm', QVariant.Double, 'double', 10, 2),
                QgsField('Ryr_mm', QVariant.Double, 'double', 10, 2),
                QgsField('bcr', QVariant.Double, 'double', 10, 4),
                QgsField('b_param', QVariant.Double, 'double', 10, 4),
                QgsField('m_param', QVariant.Double, 'double', 10, 4),
                QgsField('a_param', QVariant.Double, 'double', 10, 4)
            ]

            provider.addAttributes(fields)
            temp_layer.updateFields()

            # Алиасы
            field_aliases = {
                'FID': 'ID исходного объекта',
                'Landscape': 'Название ландшафта',
                'F_km2': 'Площадь (км²)',
                'Slope': 'Уклон (‰)',
                'Kf': 'Коэффициент фильтрации (м/сут)',
                'L_type': 'Тип ландшафта (0-дренированный, 1-заболоченный)',
                'Rsp_mm': 'Весенний сток (мм)',
                'Ryr_mm': 'Годовой сток (мм)',
                'bcr': 'Базовый коэффициент регулирования стока',
                'b_param': 'Комплексный коэффициент стока',
                'm_param': 'Показатель нелинейности',
                'a_param': 'Коэффициент аккумуляции'
            }

            for field_name, alias in field_aliases.items():
                idx = temp_layer.fields().indexFromName(field_name)
                if idx >= 0:
                    temp_layer.setFieldAlias(idx, alias)

            # Добавляем объекты
            temp_layer.startEditing()

            feature_count = 0
            for res in results:
                feature = QgsFeature()
                feature.setGeometry(res['geometry'])

                attributes = [
                    res.get('original_fid', feature_count + 1),
                    res.get('landscape_name', ''),
                    res['attributes']['F'],
                    res['attributes']['i'],
                    res['attributes']['Kf'],
                    res['attributes']['landscape_type'],
                    res['attributes']['Rsp'],
                    res['attributes']['Ryr'],
                    res['attributes']['bcr'],
                    res['attributes']['b'],
                    res['attributes']['m'],
                    res['attributes']['a']
                ]
                feature.setAttributes(attributes)
                temp_layer.addFeature(feature)
                feature_count += 1

            temp_layer.commitChanges()

            # Добавляем слой на карту
            QgsProject.instance().addMapLayer(temp_layer)

            # Помещаем в группу
            root = QgsProject.instance().layerTreeRoot()
            source_layer_id = source_layer.id()

            found_group = None
            for group in root.findGroups():
                for layer in group.findLayers():
                    if layer.layerId() == source_layer_id:
                        found_group = group
                        break
                if found_group:
                    break

            if found_group:
                found_group.addLayer(temp_layer)

            self.log_text.append(f"\n=== СОЗДАН НОВЫЙ СЛОЙ ===")
            self.log_text.append(f"Имя слоя: {layer_name}")
            self.log_text.append(f"Количество объектов: {feature_count}")
            self.log_text.append(f"Поле FID содержит ID из исходного слоя")

            self.iface.mapCanvas().refresh()

        finally:
            self._is_creating = False

    def display_results(self, results, total_area,
                        total_spring_volume, avg_spring_runoff,
                        total_year_volume, avg_year_runoff):
        """Отображение результатов в таблице"""

        # Обновляем сводку
        self.total_area_label.setText(f"Общая площадь водосбора: {total_area:.2f} км²")
        self.total_spring_volume_label.setText(f"Общий объем весеннего стока: {total_spring_volume:.2f} мм·км²")
        self.total_spring_runoff_label.setText(f"Общая величина весеннего стока: {avg_spring_runoff:.2f} мм")
        self.total_year_volume_label.setText(f"Общий объем годового стока: {total_year_volume:.2f} мм·км²")
        self.total_year_runoff_label.setText(f"Общая величина годового стока: {avg_year_runoff:.2f} мм")

        # Заполняем таблицу
        self.results_table.setRowCount(len(results))

        for i, res in enumerate(results):
            # Порядковый номер
            self.results_table.setItem(i, 0, QTableWidgetItem(str(i + 1)))
            
            # FID (оригинальный ID из исходного слоя)
            self.results_table.setItem(i, 1, QTableWidgetItem(str(res.get('original_fid', i + 1))))

            # Landscape (название ландшафта)
            landscape_name = res.get('landscape_name', '')
            self.results_table.setItem(i, 2, QTableWidgetItem(landscape_name))

            # Площадь
            self.results_table.setItem(i, 3, QTableWidgetItem(f"{res['attributes']['F']:.2f}"))

            # Доля
            share = (res['attributes']['F'] / total_area * 100) if total_area > 0 else 0
            self.results_table.setItem(i, 4, QTableWidgetItem(f"{share:.1f}"))

            # Весенний сток
            spring_item = QTableWidgetItem(f"{res['attributes']['Rsp']:.2f}")
            if res['attributes']['Rsp'] > 0:
                spring_item.setBackground(QColor(200, 255, 200))
            self.results_table.setItem(i, 5, spring_item)

            # Годовой сток
            year_item = QTableWidgetItem(f"{res['attributes']['Ryr']:.2f}")
            if res['attributes']['Ryr'] > 0:
                year_item.setBackground(QColor(200, 230, 255))
            self.results_table.setItem(i, 6, year_item)

        self.results_table.resizeColumnsToContents()